License information
===================

The OpenIPSL is released under the same license as the original iPSL project.

OpenIPSL
^^^^^^^^

All changes applied in this fork have the following copyright statement:

Copyright April 2016 - SmarTS Lab

SmarTS Lab, research group at KTH: https://www.kth.se/en
The authors can be contacted by email: luigiv@kth.se.
This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0.

iPSL:
^^^^^

The library original's copyright statement:

Copyright 2015-March 31 2016 RTE (France), SmarTS Lab (Sweden), AIA (Spain) and DTU (Denmark)

RTE: http://www.rte-france.com
SmarTS Lab, research group at KTH: https://www.kth.se/en
AIA: http://www.aia.es/en/energy
DTU: http://www.dtu.dk/english
The authors can be contacted by email: info@itesla-ipsl.org

This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0.
